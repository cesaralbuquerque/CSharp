﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvpWebApp.Models
{
    public class RepositorioBanco<T> : IRepository<T>
    {
        public List<T> Dados
        {
            get { throw new NotImplementedException(); }
        }

        public void AddNovo(T entidade)
        {
            throw new NotImplementedException();
        }

        public void Alterar(T entidade)
        {
            throw new NotImplementedException();
        }

        public T Get(int id)
        {
            throw new NotImplementedException();
        }
    }
}